from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('gallery/', views.gallery, name='gallery'),
    path('aboutus/', views.aboutus, name='aboutus'),
    path('order/', views.order_ticket, name='order_ticket'),
    path('success/<int:order_id>/', views.order_success, name='order_success'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('update-order/<int:order_id>/', views.update_order_status, name='update_order_status'),
    path('add-artist/', views.add_artist, name='add_artist'),
    path('add-concert/', views.add_concert, name='add_concert'),
    path('delete-artist/<int:artist_id>/', views.delete_artist, name='delete_artist'),
    path('delete-concert/<int:concert_id>/', views.delete_concert, name='delete_concert'),
]