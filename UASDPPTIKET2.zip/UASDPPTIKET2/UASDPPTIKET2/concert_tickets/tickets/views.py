from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test # Tambahkan user_passes_test
from django.contrib import messages
from django.db.models import Sum
from django.utils import timezone
from .models import Artist, Concert, Order
from .forms import OrderForm, ArtistForm, ConcertForm

# Fungsi pembantu untuk mengecek apakah user adalah admin/staff
def is_admin(user):
    return user.is_authenticated and user.is_staff

def home(request):
    now = timezone.now()
    artists = Artist.objects.all()[:6]
    concerts = Concert.objects.filter(date__gte=now, is_active=True).order_by('date')[:3]
    return render(request, 'home.html', {'artists': artists, 'concerts': concerts, 'now': now})

def gallery(request):
    artists = Artist.objects.all()
    return render(request, 'gallery.html', {'artists': artists})

def aboutus(request):
    return render(request, 'aboutus.html')

def order_ticket(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            concert = order.concert
            if concert.available_tickets >= order.quantity:
                order.total_price = concert.price * order.quantity
                order.save()
                concert.available_tickets -= order.quantity
                concert.save()
                messages.success(request, 'Pesanan berhasil!')
                return redirect('order_success', order_id=order.id)
            else:
                messages.error(request, 'Tiket tidak mencukupi!')
    else:
        form = OrderForm()
    return render(request, 'order.html', {'form': form})

def order_success(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, 'order_success.html', {'order': order})

# --- AREA DASHBOARD ADMIN (DIKUNCI HANYA UNTUK STAFF) ---

@user_passes_test(is_admin)
def admin_dashboard(request):
    context = {
        'total_orders': Order.objects.count(),
        'concerts': Concert.objects.all(),
        'artists': Artist.objects.all(),
        'recent_orders': Order.objects.all().order_by('-id')[:10],
    }
    return render(request, 'admin_dashboard.html', context)

@user_passes_test(is_admin)
def add_artist(request):
    if request.method == 'POST':
        form = ArtistForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Artis berhasil ditambahkan!')
            return redirect('admin_dashboard')
    else:
        form = ArtistForm()
    return render(request, 'add_artist.html', {'form': form})

@user_passes_test(is_admin)
def delete_artist(request, artist_id):
    artist = get_object_or_404(Artist, id=artist_id)
    artist.delete()
    messages.success(request, 'Artis berhasil dihapus.')
    return redirect('admin_dashboard')

@user_passes_test(is_admin)
def add_concert(request):
    if request.method == 'POST':
        form = ConcertForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Konser berhasil ditambahkan!')
            return redirect('admin_dashboard')
    else:
        form = ConcertForm()
    return render(request, 'add_concert.html', {'form': form})

@user_passes_test(is_admin)
def delete_concert(request, concert_id):
    concert = get_object_or_404(Concert, id=concert_id)
    concert.delete()
    messages.success(request, 'Konser berhasil dihapus.')
    return redirect('admin_dashboard')

@user_passes_test(is_admin)
def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if request.method == 'POST':
        status = request.POST.get('status')
        if status in ['pending', 'confirmed', 'cancelled']:
            order.status = status
            order.save()
            messages.success(request, 'Status pesanan diperbarui.')
    return redirect('admin_dashboard')