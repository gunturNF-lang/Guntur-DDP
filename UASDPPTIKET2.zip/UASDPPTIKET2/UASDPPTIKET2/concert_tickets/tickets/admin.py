from django.contrib import admin
from .models import Artist, Concert, Song, Order
from django.utils import timezone
from django.utils.html import format_html

class SongInline(admin.TabularInline):
    model = Song
    extra = 1
    fields = ['order', 'title', 'duration']
    ordering = ['order']

@admin.register(Artist)
class ArtistAdmin(admin.ModelAdmin):
    list_display = ['name', 'genre', 'created_at']
    search_fields = ['name', 'genre']
    inlines = [SongInline]

@admin.register(Concert)
class ConcertAdmin(admin.ModelAdmin):
    list_display = ['poster_thumbnail', 'title', 'artist', 'date', 'venue', 'available_tickets', 'price']
    list_editable = ['date', 'venue', 'available_tickets', 'price']    
    list_filter = ['date', 'venue']
    search_fields = ['title', 'venue', 'artist__name']

    def poster_thumbnail(self, obj):
        if obj.poster:
            return format_html('<img src="{}" style="width: 50px; height: 70px; object-fit: cover; border-radius: 4px;" />', obj.poster.url)
        return "No Image"
    
    poster_thumbnail.short_description = 'Poster'

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'name', 'concert', 'quantity', 'total_price', 'status', 'order_date']
    list_editable = ['status']
    readonly_fields = ['order_date', 'total_price']
    actions = ['make_confirmed', 'make_cancelled']

    @admin.action(description='Ubah status ke Confirmed')
    def make_confirmed(self, request, queryset):
        queryset.update(status='confirmed')

    @admin.action(description='Ubah status ke Cancelled')
    def make_cancelled(self, request, queryset):
        queryset.update(status='cancelled')

def poster_thumbnail(self, obj):
    if obj.poster:
        return format_html('<img src="{}" style="width: 50px; height: auto;" />', obj.poster.url)
    return "No Poster"