from django.db import models

class Artist(models.Model):
    name = models.CharField(max_length=100)
    genre = models.CharField(max_length=50)
    description = models.TextField()
    image = models.ImageField(upload_to='artists/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']

class Concert(models.Model):
    artist = models.ForeignKey(Artist, on_delete=models.CASCADE, related_name='concerts')
    title = models.CharField(max_length=200)
    date = models.DateTimeField() 
    venue = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=12, decimal_places=0)
    available_tickets = models.IntegerField(default=0)
    poster = models.ImageField(upload_to='concerts/', blank=True, null=True)
    is_active = models.BooleanField(default=True) 
    def __str__(self):
        return f"{self.title} - {self.artist.name}"

class Song(models.Model):
    artist = models.ForeignKey(Artist, on_delete=models.CASCADE, related_name='songs')
    title = models.CharField(max_length=200)
    duration = models.CharField(max_length=10, help_text="Contoh: 3:45")
    order = models.PositiveIntegerField(default=1, help_text="Urutan lagu (1, 2, 3...)")

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"{self.artist.name} - {self.title}"

class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('cancelled', 'Cancelled'),
    ]

    concert = models.ForeignKey(Concert, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    quantity = models.IntegerField()
    total_price = models.DecimalField(max_digits=12, decimal_places=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    order_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order #{self.id} - {self.name}"

    class Meta:
        ordering = ['-order_date']